# -*- coding: utf-8 -*-
"""
grain_wallet.py —— 算粒（Grain）钱包（带密码加密）
用法：
  python grain_wallet.py --wallet wallet.txt new    # 新建钱包（设置密码）
  python grain_wallet.py --wallet wallet.txt lock   # 查看地址（输入密码）
"""

import sys
import json
import getpass
import argparse

from grain_common import (
    generate_keypair, public_key_bytes, private_key_bytes,
    address_from_pubkey, encrypt_private_key, decrypt_private_key,
)


def cmd_new(path):
    print('Creating new Grain wallet...')
    sk, pk = generate_keypair()
    pk_b = public_key_bytes(pk)
    sk_hex = private_key_bytes(sk).hex()
    addr = address_from_pubkey(pk_b)

    # 设置密码
    while True:
        pw1 = getpass.getpass('Set password: ')
        pw2 = getpass.getpass('Confirm password: ')
        if pw1 == pw2 and len(pw1) >= 1:
            break
        print('Passwords do not match or too short, try again.')

    salt_hex, enc_hex = encrypt_private_key(sk_hex, pw1)

    data = {
        'coin': 'Grain',
        'address': addr,
        'public_key': pk_b.hex(),
        'salt': salt_hex,
        'encrypted_private_key': enc_hex,
    }
    with open(path, 'w') as f:
        json.dump(data, f, indent=2)

    print(f'Wallet created: {path}')
    print(f'Address     : {addr}')
    print('Keep your password safe. The private key is encrypted.')


def cmd_lock(path):
    with open(path) as f:
        w = json.load(f)
    # 输入密码验证
    for _ in range(3):
        pw = getpass.getpass('Enter password: ')
        try:
            decrypt_private_key(w['salt'], w['encrypted_private_key'], pw)
            print(f'Address: {w["address"]}')
            print(f'Public key: {w["public_key"]}')
            return
        except Exception:
            print('Wrong password, try again.')
    print('Too many failed attempts.')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--wallet', required=True)
    ap.add_argument('cmd', choices=['new', 'lock'])
    args = ap.parse_args()
    if args.cmd == 'new':
        cmd_new(args.wallet)
    elif args.cmd == 'lock':
        cmd_lock(args.wallet)


if __name__ == '__main__':
    main()
