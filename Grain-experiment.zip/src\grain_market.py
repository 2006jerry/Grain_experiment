# -*- coding: utf-8 -*-
"""
grain_market.py —— 算粒（Grain）算力市场核心
把"挖矿"从算无意义哈希，升级为"执行需求方提交的计算任务"：
  需求方提交任务(带预算 GRN) → 矿工领取执行 → 节点验证 → 结算(需求方付 GRN → 矿工收)
这是让 GRN 币有真实价值的核心：币 = 购买算力的凭证。
"""

import json
import time
import uuid

from grain_common import hash_hex


class Task:
    """一个可验证的计算任务"""

    def __init__(self, owner, task_type, params, budget, difficulty=4):
        self.id = uuid.uuid4().hex[:12]
        self.owner = owner              # 需求方地址
        self.task_type = task_type      # 任务类型
        self.params = params            # 任务参数
        self.budget = budget            # 需求方愿意支付的 GRN
        self.difficulty = difficulty    # 计算难度（决定算力消耗）
        self.status = 'open'            # open / assigned / done / failed
        self.assignee = None            # 被分配的矿工
        self.result = None
        self.submit_time = time.time()

    def to_dict(self):
        return {
            'id': self.id, 'owner': self.owner, 'type': self.task_type,
            'params': self.params, 'budget': self.budget,
            'difficulty': self.difficulty, 'status': self.status,
            'assignee': self.assignee, 'result': self.result,
        }


def execute_task(task):
    """矿工执行任务，返回计算结果（task 可以是 Task 对象或 dict）"""
    if isinstance(task, dict):
        task_type = task.get('type')
        params = task.get('params', {})
        difficulty = task.get('difficulty', 4)
    else:
        task_type = task.task_type
        params = task.params
        difficulty = task.difficulty
    if task_type == 'hash':
        seed = params['seed']
        target_prefix = '0' * difficulty
        nonce = 0
        while True:
            h = hash_hex(f'{seed}{nonce}')
            if h.startswith(target_prefix):
                return {'nonce': nonce, 'hash': h}
            nonce += 1
    elif task_type == 'prime':
        start = params.get('start', 10**6)
        n = params.get('n', 1)
        def is_prime(x):
            if x < 2:
                return False
            for i in range(2, int(x ** 0.5) + 1):
                if x % i == 0:
                    return False
            return True
        count = 0
        x = start
        while True:
            x += 1
            if is_prime(x):
                count += 1
                if count == n:
                    return {'prime': x}
    return None


def verify_task(task, result):
    """节点验证矿工提交的结果（task 可以是 Task 对象或 dict）"""
    if isinstance(task, dict):
        task_type = task.get('type')
        params = task.get('params', {})
        difficulty = task.get('difficulty', 4)
    else:
        task_type = task.task_type
        params = task.params
        difficulty = task.difficulty
    if task_type == 'hash':
        seed = params['seed']
        nonce = result.get('nonce')
        h = hash_hex(f'{seed}{nonce}')
        return h.startswith('0' * difficulty) and h == result.get('hash')
    elif task_type == 'prime':
        x = result.get('prime')
        if x is None:
            return False
        def is_prime(n):
            if n < 2:
                return False
            for i in range(2, int(n ** 0.5) + 1):
                if n % i == 0:
                    return False
            return True
        return is_prime(x) and x > params.get('start', 10**6)
    return False
