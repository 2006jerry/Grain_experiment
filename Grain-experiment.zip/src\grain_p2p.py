# -*- coding: utf-8 -*-
"""
grain_p2p.py —— 算粒（Grain）P2P 网络核心
基于 TCP socket 的简单对等网络：监听端口、连接 seed、收发消息、广播。
"""

import socket
import threading
import json


def send_msg(sock, msg):
    """发送一条消息（4 字节长度前缀 + JSON）"""
    data = json.dumps(msg).encode('utf-8')
    sock.sendall(len(data).to_bytes(4, 'big') + data)


def recv_msg(sock):
    """接收一条消息，连接断开返回 None"""
    header = _recv_exact(sock, 4)
    if header is None:
        return None
    length = int.from_bytes(header, 'big')
    if length <= 0 or length > 10 * 1024 * 1024:
        return None
    data = _recv_exact(sock, length)
    if data is None:
        return None
    try:
        return json.loads(data.decode('utf-8'))
    except Exception:
        return None


def _recv_exact(sock, n):
    buf = b''
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            return None
        buf += chunk
    return buf


class P2PNode:
    """P2P 网络节点：监听端口 + 连接 peer + 收发消息 + 广播"""

    def __init__(self, host, port, on_message):
        self.host = host
        self.port = port
        self.on_message = on_message  # 回调 (msg, peer) -> None
        self.peers = {}               # addr -> socket
        self.server = None
        self.running = False

    def start(self):
        """启动监听"""
        self.server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server.bind((self.host, self.port))
        self.server.listen(20)
        self.running = True
        threading.Thread(target=self._accept_loop, daemon=True).start()

    def _accept_loop(self):
        while self.running:
            try:
                sock, addr = self.server.accept()
                self.peers[addr] = sock
                threading.Thread(target=self._peer_loop, args=(sock, addr), daemon=True).start()
            except Exception:
                break

    def connect(self, host, port):
        """主动连接一个 seed 节点"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.connect((host, port))
            self.peers[(host, port)] = sock
            threading.Thread(target=self._peer_loop, args=(sock, (host, port)), daemon=True).start()
            return True
        except Exception:
            return False

    def _peer_loop(self, sock, addr):
        while self.running:
            msg = recv_msg(sock)
            if msg is None:
                break
            try:
                self.on_message(msg, addr)
            except Exception:
                pass
        sock.close()
        self.peers.pop(addr, None)

    def broadcast(self, msg):
        """向所有 peer 广播消息"""
        for sock in list(self.peers.values()):
            try:
                send_msg(sock, msg)
            except Exception:
                pass

    def send_to(self, addr, msg):
        sock = self.peers.get(addr)
        if sock:
            try:
                send_msg(sock, msg)
            except Exception:
                pass

    def peer_count(self):
        return len(self.peers)
