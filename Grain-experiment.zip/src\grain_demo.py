# -*- coding: utf-8 -*-
"""
grain-demo.py —— 算粒（Grain）演示：一键跑通挖矿→出块→coinbase→减半→难度调整
用法：python grain-demo.py --blocks 5
"""

import os
import json
import time
import argparse
import shutil

from grain_common import hash_hex, reward_at, split_coinbase, asert_adjust
from grain_node import Node


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--blocks', type=int, default=5)
    ap.add_argument('--datadir', default='data')
    args = ap.parse_args()

    if os.path.exists(args.datadir):
        shutil.rmtree(args.datadir)

    node = Node(args.datadir, 'grain1miner00000000000000000000000000000000')
    print('=' * 66)
    print('  算粒（Grain）演示 · BLAKE3 PoW + ASERT + UTXO')
    print('=' * 66)
    print(f'参数：区块 {60}s | 奖励 {20} GRN | 每 {450000} 块减半 | 5% 项目份额 | 无预挖')
    print()

    for i in range(args.blocks):
        work = node.make_work()
        height = work['height']
        target = work['target']
        header = f"{height}{work['prev_hash']}{work['timestamp']}{target}{node.miner_lock}"

        # 挖矿（CPU）
        nonce = 0
        t0 = time.time()
        while True:
            h = hash_hex(f"{header}{nonce}")
            if int(h, 16) < target:
                break
            nonce += 1
        elapsed = time.time() - t0

        # 提交 + 接受
        with open(node.submit_path, 'w') as f:
            json.dump({'work': work, 'nonce': nonce, 'miner_addr': node.miner_lock}, f)
        block = node.try_accept()

        miner_r, project_r = split_coinbase(height)
        print(f'[块 {height}] nonce={nonce} | 挖矿耗时 {elapsed:.2f}s | 哈希 {block["hash"][:16]}...')
        print(f'         奖励 {miner_r + project_r} GRN（矿工 {miner_r} + 项目方 {project_r}）')

    print()
    print('=' * 66)
    print('账本余额（UTXO 简化视图）：')
    for addr, bal in sorted(node.utxo.items(), key=lambda x: -x[1]):
        if bal > 0:
            print(f'  {addr}  →  {bal} GRN')
    print('=' * 66)


if __name__ == '__main__':
    main()
