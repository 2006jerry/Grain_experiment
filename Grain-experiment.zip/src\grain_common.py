# -*- coding: utf-8 -*-
"""
grain_common.py —— 算粒（Grain）币核心模块
货币层：UTXO + Ed25519 + BLAKE3，无虚拟机
共识：BLAKE3 工作量证明 + ASERT 难度调整
"""

import blake3
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey, Ed25519PublicKey
)
from cryptography.hazmat.primitives import serialization

# ============ 链参数（按需求设定） ============
COIN_NAME = 'Grain'
COIN_SYMBOL = 'GRN'
BLOCK_TIME = 60                # 目标区块时间（秒），ASERT 调整
INITIAL_REWARD = 20            # 初始奖励：20 GRN / 块
HALVING_INTERVAL = 450000      # 每 45 万块减半一次
PROJECT_SHARE = 0.05           # 5% 项目份额进入 coinbase
COINBASE_MATURITY = 100        # coinbase 币成熟块数
NO_PREMINING = True            # 无预挖

# 总供应量（模仿比特币算法）：初始奖励 × 减半间隔 × 2
# 20 × 450000 × 2 = 18,000,000 GRN
MAX_SUPPLY = INITIAL_REWARD * HALVING_INTERVAL * 2

# 项目方地址（coinbase 5% 归此处）。Ed25519 公钥的 BLAKE3 哈希前缀形式
PROJECT_ADDR = 'grain1project00000000000000000000000000000000'


# ============ 哈希 ============
def hash_data(data: bytes) -> bytes:
    """BLAKE3 哈希，返回 32 字节"""
    return blake3.blake3(data).digest()


def hash_hex(data) -> str:
    if isinstance(data, str):
        data = data.encode()
    return blake3.blake3(data).hexdigest()


# ============ 密钥与地址 ============
def generate_keypair():
    """生成 Ed25519 密钥对，返回 (私钥, 公钥) 字节串"""
    sk = Ed25519PrivateKey.generate()
    pk = sk.public_key()
    return sk, pk


def public_key_bytes(pk: Ed25519PublicKey) -> bytes:
    return pk.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )


def private_key_bytes(sk: Ed25519PrivateKey) -> bytes:
    return sk.private_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PrivateFormat.Raw,
        encryption_algorithm=serialization.NoEncryption(),
    )


def address_from_pubkey(pk_bytes: bytes) -> str:
    """地址 = 'grain1' + 公钥的 BLAKE3 哈希前 20 字节的 hex"""
    h = hash_data(pk_bytes)
    return 'grain1' + h[:20].hex()


def sign(sk: Ed25519PrivateKey, message: bytes) -> bytes:
    return sk.sign(message)


def verify(pk_bytes: bytes, message: bytes, signature: bytes) -> bool:
    try:
        pk = Ed25519PublicKey.from_public_bytes(pk_bytes)
        pk.verify(signature, message)
        return True
    except Exception:
        return False


# ============ 区块奖励（含减半 + 项目份额） ============
def reward_at(height: int) -> int:
    """第 height 块的 coinbase 奖励总额"""
    halvings = height // HALVING_INTERVAL
    reward = INITIAL_REWARD
    for _ in range(halvings):
        reward //= 2
        if reward == 0:
            return 0
    return reward


def split_coinbase(height: int):
    """返回 (矿工所得, 项目方所得)"""
    total = reward_at(height)
    project = int(total * PROJECT_SHARE)
    miner = total - project
    return miner, project


# ============ ASERT 难度调整（简化实现） ============
def asert_adjust(old_target: int, actual_time: float, target_time: float = BLOCK_TIME) -> int:
    """
    ASERT 核心思想：难度按"实际出块时间与目标时间的偏差"指数调整。
    ratio = 2 ^ ((actual - target) / (target * 调整周期))
    简化：直接用单块偏差做小步长指数修正。
    """
    import math
    # 偏差比例，限制在 [0.5, 2.0] 防止剧烈波动
    ratio = actual_time / target_time
    ratio = max(0.5, min(2.0, ratio))
    # 目标越小难度越高：实际时间 > 目标（慢了）→ 降难度（target 变大）
    new_target = int(old_target * ratio)
    return new_target


# ============ 钱包密码加密（PBKDF2 + Fernet） ============
import os as _os
import base64 as _b64
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.fernet import Fernet


def _derive_key(password: str, salt: bytes) -> bytes:
    kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=100000)
    return _b64.urlsafe_b64encode(kdf.derive(password.encode()))


def encrypt_private_key(sk_hex: str, password: str):
    """返回 (salt_hex, encrypted_hex)，用于加密私钥"""
    salt = _os.urandom(16)
    key = _derive_key(password, salt)
    f = Fernet(key)
    encrypted = f.encrypt(bytes.fromhex(sk_hex))
    return salt.hex(), encrypted.hex()


def decrypt_private_key(salt_hex: str, encrypted_hex: str, password: str):
    """用密码解密私钥，返回 sk_hex；密码错误抛异常"""
    salt = bytes.fromhex(salt_hex)
    encrypted = bytes.fromhex(encrypted_hex)
    key = _derive_key(password, salt)
    f = Fernet(key)
    return f.decrypt(encrypted).hex()


# ============ 硬件信息（温度/能耗，读不到返回 N/A） ============
def get_cpu_temp() -> str:
    """尝试读取 CPU 温度（摄氏），读不到返回 'N/A'"""
    try:
        import subprocess
        out = subprocess.check_output(
            'powershell -NoProfile -c "(Get-CimInstance -Namespace root/wmi '
            '-ClassName MSAcpi_ThermalZoneTemperature).CurrentTemperature"',
            shell=True).decode(errors='ignore').strip()
        val = int(out)
        return f'{val / 10 - 273.15:.1f} C'
    except Exception:
        return 'N/A'


def get_cpu_power() -> str:
    """尝试读取 CPU 功耗（瓦），读不到返回 'N/A'（Windows 普遍读不到）"""
    return 'N/A'
