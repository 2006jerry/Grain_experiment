# -*- coding: utf-8 -*-
"""
grain_market_demo.py —— 算粒（Grain）算力市场演示
展示完整价值闭环：需求方付费 GRN 购买算力 → 矿工执行任务赚 GRN → 验证结算。
用法：python grain_market_demo.py
"""

import time

from grain_market import Task, execute_task, verify_task


def main():
    print('=' * 64)
    print('  Grain Compute Market · 价值闭环演示')
    print('=' * 64)

    # 账户余额（简化账本）
    balance = {
        'Alice (需求方/AI公司)': 100,
        'Bob (矿工)': 0,
    }

    print('\n初始余额：')
    for k, v in balance.items():
        print(f'  {k}: {v} GRN')
    print()

    # 需求方提交任务
    tasks = [
        Task('Alice (需求方/AI公司)', 'hash', {'seed': 'grain-task-1'}, budget=15, difficulty=5),
        Task('Alice (需求方/AI公司)', 'prime', {'start': 500000, 'n': 1}, budget=10),
    ]

    fee_rate = 0.05  # 网络手续费 5%

    for task in tasks:
        print(f'[任务 {task.id}] 类型={task.task_type} 预算={task.budget} GRN 难度={task.difficulty}')
        print(f'  → 需求方 Alice 提交任务，锁定 {task.budget} GRN')

        # 矿工执行
        t0 = time.time()
        print(f'  → 矿工 Bob 开始执行...')
        result = execute_task(task)
        elapsed = time.time() - t0
        print(f'  → 执行完成，耗时 {elapsed:.2f}s，结果={result}')

        # 验证
        ok = verify_task(task, result)
        print(f'  → 节点验证：{"通过" if ok else "失败"}')

        # 结算
        if ok:
            fee = task.budget * fee_rate
            miner_get = task.budget - fee
            balance['Alice (需求方/AI公司)'] -= task.budget
            balance['Bob (矿工)'] += miner_get
            print(f'  → 结算：Alice 支付 {task.budget} GRN，Bob 实得 {miner_get:.1f} GRN，'
                  f'网络抽 {fee:.1f} GRN')
        print()

    print('=' * 64)
    print('最终余额：')
    for k, v in balance.items():
        print(f'  {k}: {v} GRN')
    print('=' * 64)
    print()
    print('这就是价值闭环：GRN 币 = 购买算力的钱。')
    print('需求方要算力 → 必须买 GRN → 矿工赚 GRN → 币有真实需求。')


if __name__ == '__main__':
    main()
