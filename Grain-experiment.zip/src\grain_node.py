# -*- coding: utf-8 -*-
"""
grain_node.py —— 算粒（Grain）节点（P2P 版）
UTXO 账本 + 区块 + BLAKE3 PoW + ASERT + coinbase + P2P 网络。
用法：
  python grain_node.py --run --datadir data --miner-lock grain1xxx --port 3440 [--seed HOST:PORT]
"""

import os
import json
import time
import argparse

from grain_common import (
    hash_hex, reward_at, split_coinbase, asert_adjust,
    BLOCK_TIME, COIN_NAME, MAX_SUPPLY,
)
from grain_p2p import P2PNode
from grain_rpc import RPCServer
from grain_market import Task, verify_task


def genesis_block():
    return {
        'height': 0,
        'prev_hash': '0' * 64,
        'timestamp': 0,
        'nonce': 0,
        'target': 2 ** 255,
        'coinbase_miner': 'genesis',
        'coinbase_project': 'genesis',
        'miner_reward': 0,
        'project_reward': 0,
        'hash': hash_hex('genesis-block'),
    }


def valid_block(prev, block):
    """验证区块是否合法（接到 prev 之后）"""
    if block['prev_hash'] != prev['hash']:
        return False
    header = (f"{block['height']}{block['prev_hash']}{block['timestamp']}"
              f"{block['target']}{block['coinbase_miner']}")
    h = hash_hex(f"{header}{block['nonce']}")
    if h != block['hash'] or int(h, 16) >= block['target']:
        return False
    mr, pr = split_coinbase(block['height'])
    if block['miner_reward'] != mr or block['project_reward'] != pr:
        return False
    return True


class Node:
    def __init__(self, datadir, miner_lock, host='0.0.0.0', port=3440, rpc_port=3441, seeds=None):
        self.datadir = datadir
        self.miner_lock = miner_lock
        self.host = host
        self.port = port
        self.rpc_port = rpc_port
        self.seeds = seeds or []
        self.chain_path = os.path.join(datadir, 'chain.json')
        self.work_path = os.path.join(datadir, 'work.json')
        self.submit_path = os.path.join(datadir, 'submit.json')
        os.makedirs(datadir, exist_ok=True)
        self.chain = self._load_chain()
        self.utxo = self._load_utxo()
        self.miners = {}
        self.tasks = []  # 算力市场任务池
        self.p2p = None

    def _load_chain(self):
        if os.path.exists(self.chain_path):
            with open(self.chain_path) as f:
                return json.load(f)
        return [genesis_block()]

    def _load_utxo(self):
        bal = {}
        for b in self.chain[1:]:
            bal[b['coinbase_miner']] = bal.get(b['coinbase_miner'], 0) + b['miner_reward']
            bal[b['coinbase_project']] = bal.get(b['coinbase_project'], 0) + b['project_reward']
        return bal

    def _save(self):
        with open(self.chain_path, 'w') as f:
            json.dump(self.chain, f, indent=2)

    def _target(self):
        last = self.chain[-1]
        if last['height'] == 0:
            return 2 ** 240
        return last['target']

    def active_miners(self):
        now = time.time()
        active = {a: m for a, m in self.miners.items() if now - m['last'] < 600}
        return len(active), sum(m['hashrate'] for m in active.values())

    def make_work(self):
        last = self.chain[-1]
        n_miners, total_hash = self.active_miners()
        work = {
            'height': last['height'] + 1,
            'prev_hash': last['hash'],
            'timestamp': int(time.time()),
            'target': self._target(),
            'miner_lock': self.miner_lock,
            'miners': n_miners,
            'total_hashrate': total_hash,
            'max_supply': MAX_SUPPLY,
        }
        with open(self.work_path, 'w') as f:
            json.dump(work, f)
        return work

    def add_block(self, block):
        """验证并加入一个区块，返回是否成功"""
        if block['height'] != self.chain[-1]['height'] + 1:
            return False
        if not valid_block(self.chain[-1], block):
            return False
        self.chain.append(block)
        self.utxo[block['coinbase_miner']] = self.utxo.get(block['coinbase_miner'], 0) + block['miner_reward']
        self.utxo['grain1project00000000000000000000000000000000'] = \
            self.utxo.get('grain1project00000000000000000000000000000000', 0) + block['project_reward']
        self._save()
        self.make_work()
        return True

    def try_accept(self):
        """接受矿工提交的区块（本地文件方式，兼容旧版），成功则广播"""
        if not os.path.exists(self.submit_path):
            return None
        with open(self.submit_path) as f:
            sub = json.load(f)
        os.remove(self.submit_path)
        block = self._accept_submit(sub['work'], sub['nonce'],
                                    sub.get('miner_addr', self.miner_lock),
                                    sub.get('hashrate', 0.0))
        return block

    def _accept_submit(self, work, nonce, miner_addr, hashrate):
        """验证并接受矿工提交的区块，成功则广播，返回区块或 None"""
        header = f"{work['height']}{work['prev_hash']}{work['timestamp']}{work['target']}{miner_addr}"
        block_hash = hash_hex(f"{header}{nonce}")
        if int(block_hash, 16) >= work['target']:
            return None
        miner_r, project_r = split_coinbase(work['height'])
        block = {
            'height': work['height'],
            'prev_hash': work['prev_hash'],
            'timestamp': work['timestamp'],
            'nonce': nonce,
            'target': work['target'],
            'coinbase_miner': miner_addr,
            'coinbase_project': 'grain1project00000000000000000000000000000000',
            'miner_reward': miner_r,
            'project_reward': project_r,
            'hash': block_hash,
        }
        if not self.add_block(block):
            return None
        self.miners[miner_addr] = {'hashrate': hashrate, 'last': time.time()}
        if self.p2p:
            self.p2p.broadcast({'type': 'new_block', 'block': block})
        return block

    def _rpc_submit(self, req):
        """RPC 提交处理"""
        work = req.get('work')
        nonce = req.get('nonce')
        if work is None or nonce is None:
            return {'ok': False, 'error': 'missing work or nonce'}
        miner_addr = req.get('miner_addr', self.miner_lock)
        hashrate = req.get('hashrate', 0.0)
        block = self._accept_submit(work, nonce, miner_addr, hashrate)
        if block:
            return {'ok': True, 'block': block}
        return {'ok': False, 'error': 'invalid submission'}

    def _rpc_post_task(self, req):
        """需求方发布算力任务"""
        owner = req.get('owner')
        task_type = req.get('task_type')
        params = req.get('params', {})
        budget = int(req.get('budget', 0))
        difficulty = int(req.get('difficulty', 4))
        if not owner or budget <= 0:
            return {'ok': False, 'error': 'invalid task'}
        if self.utxo.get(owner, 0) < budget:
            return {'ok': False, 'error': 'insufficient balance'}
        task = Task(owner, task_type, params, budget, difficulty)
        self.tasks.append(task)
        self.utxo[owner] = self.utxo.get(owner, 0) - budget  # 锁定预算
        return {'ok': True, 'task': task.to_dict()}

    def _rpc_get_task(self, req):
        """矿工领取任务"""
        miner_addr = req.get('miner_addr', '')
        for t in self.tasks:
            if t.status == 'open':
                t.status = 'assigned'
                t.assignee = miner_addr
                return {'ok': True, 'task': t.to_dict()}
        return {'ok': False, 'error': 'no open task'}

    def _rpc_submit_task(self, req):
        """矿工提交任务结果，节点验证并结算"""
        task_id = req.get('task_id')
        miner_addr = req.get('miner_addr', '')
        result = req.get('result')
        for t in self.tasks:
            if t.id == task_id and t.status == 'assigned':
                if verify_task(t, result):
                    fee = int(t.budget * 0.05)
                    miner_get = t.budget - fee
                    self.utxo[miner_addr] = self.utxo.get(miner_addr, 0) + miner_get
                    self.utxo['grain1project00000000000000000000000000000000'] = \
                        self.utxo.get('grain1project00000000000000000000000000000000', 0) + fee
                    t.status = 'done'
                    t.result = result
                    return {'ok': True, 'miner_reward': miner_get, 'fee': fee}
                return {'ok': False, 'error': 'invalid result'}
        return {'ok': False, 'error': 'task not found'}

    def on_message(self, msg, addr):
        """处理 P2P 收到的消息"""
        t = msg.get('type')
        if t == 'new_block':
            block = msg.get('block')
            if block and block['height'] == self.chain[-1]['height'] + 1:
                if self.add_block(block):
                    print(f'  [P2P] received & accepted block {block["height"]} from {addr}')
                    # 转发给其他 peer（除了来源）
                    for a, sock in list(self.p2p.peers.items()):
                        if a != addr:
                            try:
                                from grain_p2p import send_msg
                                send_msg(sock, msg)
                            except Exception:
                                pass
        elif t == 'get_chain':
            from_h = msg.get('height', 0)
            blocks = self.chain[from_h + 1:]
            self.p2p.send_to(addr, {'type': 'chain', 'blocks': blocks})
        elif t == 'chain':
            for block in msg.get('blocks', []):
                if block['height'] == self.chain[-1]['height'] + 1:
                    self.add_block(block)
                elif block['height'] <= self.chain[-1]['height']:
                    continue

    def sync(self):
        """向所有 seed 请求新区块"""
        if self.p2p:
            self.p2p.broadcast({'type': 'get_chain', 'height': self.chain[-1]['height']})

    def run(self):
        print(f'{COIN_NAME} node started. Data dir: {self.datadir}')
        print(f'Height: {self.chain[-1]["height"]}  Max supply: {MAX_SUPPLY:,} GRN')

        # 启动 P2P
        self.p2p = P2PNode(self.host, self.port, self.on_message)
        self.p2p.start()
        print(f'P2P listening on {self.host}:{self.port}')

        # 启动 RPC（矿工连接用）
        self.rpc = RPCServer(self.host, self.rpc_port, {
            'get_work': lambda req: {'work': self.make_work()},
            'submit': lambda req: self._rpc_submit(req),
            'stats': lambda req: {'miners': self.active_miners()[0],
                                  'total_hashrate': self.active_miners()[1],
                                  'height': self.chain[-1]['height'],
                                  'peers': self.p2p.peer_count()},
            'post_task': lambda req: self._rpc_post_task(req),
            'get_task': lambda req: self._rpc_get_task(req),
            'submit_task': lambda req: self._rpc_submit_task(req),
        })
        self.rpc.start()
        print(f'RPC listening on {self.host}:{self.rpc_port}')
        for s in self.seeds:
            parts = s.split(':')
            host, port = parts[0], int(parts[1])
            if self.p2p.connect(host, port):
                print(f'Connected to seed {host}:{port}')
            else:
                print(f'Failed to connect seed {host}:{port}')

        self.make_work()
        time.sleep(1)
        self.sync()  # 同步已有区块

        print('Node running, waiting for miners... (Ctrl+C to stop)')
        while True:
            block = self.try_accept()
            if block:
                total = block['miner_reward'] + block['project_reward']
                n_miners, total_hash = self.active_miners()
                print(f'[Block {block["height"]}] reward {total} GRN '
                      f'(miner {block["miner_reward"]} + project {block["project_reward"]})'
                      f' | miners {n_miners} | peers {self.p2p.peer_count()}')
            time.sleep(0.5)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--run', action='store_true')
    ap.add_argument('--datadir', default='data')
    ap.add_argument('--miner-lock', default='grain1miner00000000000000000000000000000000')
    ap.add_argument('--host', default='0.0.0.0')
    ap.add_argument('--port', type=int, default=3440)
    ap.add_argument('--seed', action='append', default=[], help='seed 节点 HOST:PORT，可多个')
    args = ap.parse_args()
    if args.run:
        Node(args.datadir, args.miner_lock, args.host, args.port, args.seed).run()


if __name__ == '__main__':
    main()
