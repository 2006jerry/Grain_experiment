# -*- coding: utf-8 -*-
"""
grain_rpc.py —— 算粒（Grain）RPC 通信（节点与矿工之间）
简单 JSON-RPC：请求-响应，长连接。复用 grain_p2p 的消息格式。
"""

import socket
import threading

from grain_p2p import send_msg, recv_msg


class RPCServer:
    """RPC 服务器：监听端口，处理请求"""

    def __init__(self, host, port, handlers):
        self.host = host
        self.port = port
        self.handlers = handlers  # {cmd: func(req) -> resp}
        self.server = None
        self.running = False

    def start(self):
        self.server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server.bind((self.host, self.port))
        self.server.listen(50)
        self.running = True
        threading.Thread(target=self._loop, daemon=True).start()

    def _loop(self):
        while self.running:
            try:
                sock, addr = self.server.accept()
                threading.Thread(target=self._handle, args=(sock,), daemon=True).start()
            except Exception:
                break

    def _handle(self, sock):
        while self.running:
            req = recv_msg(sock)
            if req is None:
                break
            cmd = req.get('cmd')
            handler = self.handlers.get(cmd)
            if handler:
                try:
                    resp = handler(req)
                except Exception as e:
                    resp = {'error': str(e)}
            else:
                resp = {'error': f'unknown cmd: {cmd}'}
            try:
                send_msg(sock, resp)
            except Exception:
                break
        sock.close()


class RPCClient:
    """RPC 客户端：连接服务器，发起请求"""

    def __init__(self, host, port):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.connect((host, port))

    def call(self, msg):
        send_msg(self.sock, msg)
        return recv_msg(self.sock)

    def close(self):
        try:
            self.sock.close()
        except Exception:
            pass
