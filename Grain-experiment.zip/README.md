# Grain（算粒）

Grain 是一个以「去中心化 AI 算力市场」为核心概念的开源实验项目。它借鉴比特币的减半机制与 UTXO 模型，并尝试将矿工的算力引导到真实有用的计算上——需求方付费购买算力，矿工执行任务赚取代币，形成价值闭环。

> ⚠️ 本项目为教育与技术研究用途，代币无现实价值，详见 [免责声明](DISCLAIMER.md)。

## 特性

- **有用工作量证明（PoUW）**：挖矿与算力市场结合，矿工可执行需求方提交的计算任务；
- **P2P 网络**：节点之间互联、广播新区块、同步账本；
- **算力市场**：需求方发布任务 → 矿工执行 → 节点验证 → 结算；
- **矿工 RPC**：矿工可通过网络远程连接节点挖矿，无需与节点同机；
- **终端仪表盘**：全英文实时仪表盘，显示算力、区块数、矿工数、总算力、设备型号等。

## 技术参数

| 参数 | 值 |
|---|---|
| 币名 / 符号 | Grain / GRN |
| 区块时间 | 目标 60 秒（ASERT 难度调整） |
| 区块奖励 | 20 GRN |
| 减半 | 每 450,000 块减半 |
| 总供应量 | 18,000,000 GRN |
| 项目份额 | 5% 进入 coinbase |
| 预挖 | 无 |
| 货币层 | UTXO + Ed25519 + BLAKE3，无虚拟机 |
| 共识 | BLAKE3 PoW + ASERT |

## 目录结构

```
src/                  # 源码
  grain_common.py       # 核心：哈希、密钥、奖励、难度、钱包加密
  grain_node.py         # 节点：账本、区块、P2P、RPC、任务市场
  grain_wallet.py       # 钱包：Ed25519 + 密码加密
  grain_miner_cpu.py    # CPU 矿工（终端仪表盘）
  grain_miner_gpu.py    # GPU 矿工（多线程模拟）
  grain_p2p.py          # P2P 网络核心
  grain_rpc.py          # RPC 通信（节点-矿工）
  grain_market.py       # 算力市场核心
  grain_demo.py         # 一键演示
  grain_market_demo.py  # 价值闭环演示
docs/                 # 文档
  whitepaper.md         # 白皮书
data/                 # 数据
  grain-datasets.bin    # 数据集（占位）
```

## 快速开始

### 依赖

```bash
pip install blake3 cryptography
```

### 单机演示

```bash
cd src
python grain_demo.py --blocks 5          # 一键挖矿演示
python grain_market_demo.py              # 算力市场价值闭环演示
```

### 启动一个网络

**节点（seed）**：
```bash
python grain_node.py --run --datadir data --miner-lock grain1地址 --host 0.0.0.0 --port 3440
```

**另一台机器的节点（连 seed）**：
```bash
python grain_node.py --run --datadir data --miner-lock grain1地址 --port 3440 --seed 第一台机器IP:3440
```

**矿工（连任意节点的 RPC 端口 3441）**：
```bash
python grain_miner_cpu.py --node 节点IP:3441 --wallet wallet.txt
```

### 钱包

```bash
python grain_wallet.py --wallet wallet.txt new    # 新建（设密码）
python grain_wallet.py --wallet wallet.txt lock   # 查看（输密码）
```

## 算力市场（RPC 接口）

节点 RPC 提供以下接口（JSON-RPC）：

- `get_work`：获取待挖工作
- `submit`：提交区块
- `post_task`：需求方发布任务（含预算 GRN）
- `get_task`：矿工领取任务
- `submit_task`：提交任务结果并结算
- `stats`：查询网络状态

## 许可证与免责声明

本项目采用 [MIT 许可证](LICENSE)。使用前请阅读[免责声明](DISCLAIMER.md)。
