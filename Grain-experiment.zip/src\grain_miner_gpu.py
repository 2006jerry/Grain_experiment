# -*- coding: utf-8 -*-
"""
grain_miner_gpu.py —— 算粒（Grain）GPU 矿工（终端仪表盘版）
多线程模拟 GPU 并行，终端仪表盘显示设备型号 / 算力 / 区块数。
用法：python grain_miner_gpu.py --node data --wallet wallet.txt --threads 8
"""

import os
import sys
import json
import time
import argparse
from concurrent.futures import ThreadPoolExecutor

from grain_common import hash_hex
from grain_miner_cpu import (
    get_cpu_model, get_gpu_model, render, fmt_hashrate, fmt_uptime, _enable_ansi_windows,
)


def mine_parallel(work, miner_addr, threads, info):
    height = work['height']
    header = f"{height}{work['prev_hash']}{work['timestamp']}{work['target']}{miner_addr}"
    target = work['target']
    found = [False]

    def worker(start):
        nonce = start
        while not found[0]:
            h = hash_hex(f"{header}{nonce}")
            if int(h, 16) < target:
                found[0] = True
                return nonce, h
            nonce += threads
            info['total_hashes'] += 1
            if nonce % (threads * 2000) == 0:
                info['nonce'] = nonce
                info['last_hash'] = h
                info['uptime'] = time.time() - info['start_time']
                info['hps'] = info['total_hashes'] / max(1, info['uptime'])
                render(info)
        return None, None

    with ThreadPoolExecutor(max_workers=threads) as ex:
        futures = [ex.submit(worker, i) for i in range(threads)]
        for fut in futures:
            nonce, h = fut.result()
            if nonce is not None:
                return nonce, h
    return None, None


def main():
    _enable_ansi_windows()
    ap = argparse.ArgumentParser()
    ap.add_argument('--node', required=True)
    ap.add_argument('--wallet', default=None)
    ap.add_argument('--threads', type=int, default=8)
    args = ap.parse_args()

    work_path = os.path.join(args.node, 'work.json')
    submit_path = os.path.join(args.node, 'submit.json')

    miner_addr = 'grain1miner00000000000000000000000000000000'
    if args.wallet and os.path.exists(args.wallet):
        with open(args.wallet) as f:
            miner_addr = json.load(f)['address']

    info = {
        'cpu': get_cpu_model(), 'gpu': get_gpu_model(), 'hps': 0.0, 'blocks': 0,
        'uptime': 0.0, 'last_hash': '', 'nonce': 0,
        'total_hashes': 0, 'start_time': time.time(), 'status': '',
        'miners': 0, 'total_hashrate': 0.0, 'max_supply': 18000000,
        'temp': 'N/A', 'power': 'N/A', 'last_hw': 0,
    }

    sys.stdout.write('\033[2J\033[H')
    render(info)

    last_height = -1
    while True:
        if not os.path.exists(work_path):
            info['status'] = 'waiting for node...'
            render(info)
            time.sleep(1)
            continue
        with open(work_path) as f:
            work = json.load(f)
        info['miners'] = work.get('miners', 0)
        info['total_hashrate'] = work.get('total_hashrate', 0.0)
        info['max_supply'] = work.get('max_supply', 18000000)
        if work['height'] == last_height:
            time.sleep(0.3)
            continue
        last_height = work['height']
        info['status'] = f'mining block {work["height"]} ({args.threads} threads)...'
        render(info)

        nonce, h = mine_parallel(work, miner_addr, args.threads, info)
        info['blocks'] += 1
        info['total_hashes'] += 1
        info['uptime'] = time.time() - info['start_time']
        info['hps'] = info['total_hashes'] / max(1, info['uptime'])
        info['last_hash'] = h
        info['nonce'] = nonce
        info['status'] = f'[BLOCK FOUND] height={work["height"]}  nonce={nonce}'

        with open(submit_path, 'w') as f:
            json.dump({'work': work, 'nonce': nonce, 'miner_addr': miner_addr,
                       'hashrate': info['hps']}, f)
        render(info)
        time.sleep(1)


if __name__ == '__main__':
    main()
