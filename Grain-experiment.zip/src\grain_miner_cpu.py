# -*- coding: utf-8 -*-
"""
grain_miner_cpu.py —— 算粒（Grain）CPU 矿工（终端仪表盘版）
英文终端仪表盘，居中布局，显示 hashrate / 设备型号 / 区块数 / 矿工数 / 总算力 / 温度能耗。
用法：python grain_miner_cpu.py --node data --wallet wallet.txt
"""

import os
import sys
import json
import time
import platform
import argparse
import subprocess
import datetime

from grain_common import (
    hash_hex, MAX_SUPPLY, get_cpu_temp, get_cpu_power,
)
from grain_rpc import RPCClient

C_RESET = '\033[0m'
C_GOLD = '\033[38;5;220m'
C_GREEN = '\033[32m'
C_CYAN = '\033[36m'
C_DIM = '\033[90m'
C_BOLD = '\033[1m'

GRAIN_ICON = [
    '      ▄▄▄▄▄',
    '   ▄█████████▄',
    '  ███░░██░░███',
    '  ███░░██░░███',
    '   ▀█████████▀',
    '      ▀▀▀▀▀',
]
GRAIN_LOGO = [
    ' ██████╗  ██████╗   █████╗  ██╗███╗   ██╗',
    '██╔════╝  ██╔══██╗ ██╔══██╗ ██║████╗  ██║',
    '██║  ███╗ ██████╔╝ ███████║ ██║██╔██╗ ██║',
    '██║   ██║ ██╔══██╗ ██╔══██║ ██║██║╚██╗██║',
    '╚██████╔╝ ██║  ██║ ██║  ██║ ██║██║ ╚████║',
    ' ╚═════╝  ╚═╝  ╚═╝ ╚═╝  ╚═╝ ╚═╝╚═╝  ╚═══╝',
]


def _enable_ansi_windows():
    if os.name == 'nt':
        try:
            import ctypes
            k = ctypes.windll.kernel32
            k.SetConsoleMode(k.GetStdHandle(-11), 7)
        except Exception:
            pass


def get_cpu_model():
    try:
        import winreg
        k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                           r'HARDWARE\DESCRIPTION\System\CentralProcessor\0')
        name, _ = winreg.QueryValueEx(k, 'ProcessorNameString')
        winreg.CloseKey(k)
        return name.strip()
    except Exception:
        pass
    return platform.processor() or 'Unknown CPU'


def get_gpu_model():
    try:
        import winreg
        base = r'SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}'
        k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, base)
        n = winreg.QueryInfoKey(k)[0]
        for i in range(n):
            sub = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, base + '\\' + winreg.EnumKey(k, i))
            try:
                desc, _ = winreg.QueryValueEx(sub, 'DriverDesc')
                winreg.CloseKey(sub)
                winreg.CloseKey(k)
                return desc.strip()
            except Exception:
                winreg.CloseKey(sub)
        winreg.CloseKey(k)
    except Exception:
        pass
    return 'No GPU detected'


def fmt_hashrate(hps):
    if hps >= 1e6:
        return f'{hps/1e6:.2f} MH/s'
    if hps >= 1e3:
        return f'{hps/1e3:.2f} KH/s'
    return f'{hps:.2f} H/s'


def fmt_uptime(sec):
    h = int(sec // 3600)
    m = int((sec % 3600) // 60)
    s = int(sec % 60)
    return f'{h:02d}:{m:02d}:{s:02d}'


def render(info):
    sys.stdout.write('\033[H')
    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    # 温度/能耗缓存 10 秒读一次（powershell 调用较慢）
    if time.time() - info.get('last_hw', 0) > 10:
        info['temp'] = get_cpu_temp()
        info['power'] = get_cpu_power()
        info['last_hw'] = time.time()

    out = []
    for ic in GRAIN_ICON:
        out.append(C_GOLD + ic.center(58) + C_RESET)
    out.append('')
    for lg in GRAIN_LOGO:
        out.append(C_GOLD + C_BOLD + lg.center(58) + C_RESET)
    out.append(C_DIM + '─' * 58 + C_RESET)

    pad = ' ' * 8
    rows = [
        ('Time', C_CYAN + C_BOLD + now + C_RESET),
        ('Engine', C_CYAN + 'CPU' + C_RESET),
        ('Device', info['cpu'][:36]),
        ('Hashrate', C_GOLD + C_BOLD + fmt_hashrate(info['hps']).ljust(36) + C_RESET),
        ('Blocks', C_GREEN + C_BOLD + str(info['blocks']).ljust(36) + C_RESET),
        ('Max supply', C_GOLD + f'{info["max_supply"]:,} GRN'.ljust(36) + C_RESET),
        ('Miners', C_CYAN + str(info['miners']).ljust(36) + C_RESET),
        ('Net hashrate', C_CYAN + fmt_hashrate(info['total_hashrate']).ljust(36) + C_RESET),
        ('Temp', info.get('temp', 'N/A')),
        ('Power', info.get('power', 'N/A')),
        ('Uptime', fmt_uptime(info['uptime']).ljust(36)),
        ('Current hash', C_DIM + info['last_hash'][:36].ljust(36) + C_RESET),
    ]
    for label, value in rows:
        out.append(pad + label.ljust(12) + ': ' + value)

    out.append(C_DIM + '─' * 58 + C_RESET)
    if info['status']:
        out.append('  ' + C_GREEN + C_BOLD + info['status'].center(52) + C_RESET)
    else:
        out.append('  ' + C_DIM + 'mining... (Ctrl+C to quit)'.center(52) + C_RESET)

    sys.stdout.write('\n'.join(out))
    sys.stdout.flush()


def mine(work, miner_addr, info):
    height = work['height']
    header = f"{height}{work['prev_hash']}{work['timestamp']}{work['target']}{miner_addr}"
    target = work['target']
    nonce = 0
    t0 = time.time()
    while True:
        h = hash_hex(f"{header}{nonce}")
        if int(h, 16) < target:
            elapsed = time.time() - t0
            info['last_hash'] = h
            info['nonce'] = nonce
            return nonce, h, (info['total_hashes'] / max(1, info['uptime']))
        nonce += 1
        info['total_hashes'] += 1
        if nonce % 5000 == 0:
            info['nonce'] = nonce
            info['last_hash'] = h
            info['uptime'] = time.time() - info['start_time']
            info['hps'] = info['total_hashes'] / max(1, info['uptime'])
            render(info)


def main():
    _enable_ansi_windows()
    ap = argparse.ArgumentParser()
    ap.add_argument('--node', required=True, help='node RPC address HOST:PORT')
    ap.add_argument('--wallet', default=None)
    args = ap.parse_args()

    if ':' in args.node:
        host, port = args.node.rsplit(':', 1)
        port = int(port)
    else:
        host, port = '127.0.0.1', 3441

    miner_addr = 'grain1miner00000000000000000000000000000000'
    if args.wallet and os.path.exists(args.wallet):
        with open(args.wallet) as f:
            miner_addr = json.load(f)['address']

    info = {
        'cpu': get_cpu_model(), 'gpu': get_gpu_model(), 'hps': 0.0, 'blocks': 0,
        'uptime': 0.0, 'last_hash': '', 'nonce': 0, 'total_hashes': 0,
        'start_time': time.time(), 'status': '', 'miners': 0, 'total_hashrate': 0.0,
        'max_supply': MAX_SUPPLY, 'temp': 'N/A', 'power': 'N/A', 'last_hw': 0,
    }

    sys.stdout.write('\033[2J\033[H')
    render(info)

    try:
        rpc = RPCClient(host, port)
    except Exception as e:
        print(f'Cannot connect to node {host}:{port}: {e}')
        return

    last_height = -1
    while True:
        resp = rpc.call({'cmd': 'get_work'})
        work = resp.get('work')
        if not work:
            info['status'] = 'waiting for node...'
            render(info)
            time.sleep(1)
            continue

        info['miners'] = work.get('miners', 0)
        info['total_hashrate'] = work.get('total_hashrate', 0.0)
        info['max_supply'] = work.get('max_supply', MAX_SUPPLY)

        if work['height'] == last_height:
            time.sleep(0.3)
            continue

        last_height = work['height']
        info['status'] = f'mining block {work["height"]}...'
        render(info)

        nonce, h, _ = mine(work, miner_addr, info)
        info['total_hashes'] += 1
        info['uptime'] = time.time() - info['start_time']
        info['hps'] = info['total_hashes'] / max(1, info['uptime'])

        resp = rpc.call({'cmd': 'submit', 'work': work, 'nonce': nonce,
                         'miner_addr': miner_addr, 'hashrate': info['hps']})
        if resp.get('ok'):
            info['blocks'] += 1
            info['status'] = f'[BLOCK FOUND] height={work["height"]}  nonce={nonce}'
        else:
            info['status'] = f'submit rejected: {resp.get("error", "")}'
        render(info)
        time.sleep(0.5)


if __name__ == '__main__':
    main()
